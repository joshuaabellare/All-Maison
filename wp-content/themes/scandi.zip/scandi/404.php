<?php
/**
 * @package 	WordPress
 * @subpackage 	Scandi
 * @version 	1.0.2
 * 
 * 404 Error Page Template
 * Created by CMSMasters
 * 
 */


get_header();


get_template_part('theme-framework/theme-style' . CMSMASTERS_THEME_STYLE . '/template/404');


get_footer();

