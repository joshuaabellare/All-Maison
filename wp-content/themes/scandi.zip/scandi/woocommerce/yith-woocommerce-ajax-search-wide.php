<?php
/**
 * YITH WooCommerce Ajax Search template
 *
 * @author  Yithemes
 * @package YITH WooCommerce Ajax Search Premium
 * @version 1.2.3
 * 
 * @cmsmasters_package 	Scandi
 * @cmsmasters_version 	1.0.0
 */


if ( !defined( 'YITH_WCAS' ) ) {
    exit;
} // Exit if accessed directly


include(get_template_directory() . '/woocommerce/cmsmasters-framework/theme-style' . CMSMASTERS_THEME_STYLE . '/yith-woocommerce-ajax-search/templates/yith-woocommerce-ajax-search-wide.php');